package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table
public class Call {
	@Id
	@JsonIgnore
	@Column
	private long nino;

	@Column
	private long fees;
	

	



	public long getNino() {
		return nino;
	}

	public void setId(long nino) {
		this.nino =nino;
	}
	public long getFees() {
		return fees;
	}

	public void setFees(long fees) {
	 this.fees= fees;
	}

	
	
	}

