package com.example.demo;





import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CalService {
@Autowired
CalRepository calrepo;


public List<Call> getCalculatorById(long nino) {
    return  (List<Call>) calrepo.findAll();
}






}
