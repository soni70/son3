package com.example.demo;





import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/cal/")
public class CalController {
	@org.springframework.beans.factory.annotation.Autowired(required=true)
CalService cal;

@GetMapping("/cally/{nino}")
private List<Call> getCalculator(@PathVariable("nino") long nino) {
    return cal.getCalculatorById(nino);
}


}
